﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EncryptionDecryptionKey
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //string EncryptionKey = "foxle@rn";
        private void tbnClear_Click(object sender, EventArgs e)
        {
            txtInputText.Text = "";
            txtResult.Text = "";
           // txtProductKey.Text = "";
        }
        //Referent https://www.youtube.com/watch?v=ysxC6-AFEYg
        private void btnEncrypt_Click(object sender, EventArgs e)
        {
             string EncryptionKey;
             EncryptionKey = txtProductKey.Text;
            //string EncryptionKey = "MAKV2SPBNI99212$@%#";
            byte[] data = Encoding.Unicode.GetBytes(txtInputText.Text);
            using (Aes encryptor =Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6E, 0x20, 0x4D, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms =new MemoryStream())                
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(data, 0, data.Length);
                        cs.Close();
                    }

                    txtResult.Text = Convert.ToBase64String(ms.ToArray());
                }
               
            }
        }
         private void btnDecrypt_Click(object sender, EventArgs e)
        {
            string EncryptionKey;
            EncryptionKey = txtProductKey.Text;
            byte[] data = Convert.FromBase64String(txtInputText.Text);
            using (Aes encryptor = Aes.Create())
            {
                Rfc2898DeriveBytes pdb = new Rfc2898DeriveBytes(EncryptionKey, new byte[] { 0x49, 0x76, 0x61, 0x6E, 0x20, 0x4D, 0x65, 0x64, 0x76, 0x65, 0x64, 0x65, 0x76 });
                encryptor.Key = pdb.GetBytes(32);
                encryptor.IV = pdb.GetBytes(16);
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(data, 0, data.Length);
                        cs.Close();
                    }
                    txtResult.Text = Encoding.Unicode.GetString(ms.ToArray());
                }

            }
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                txtProductKey.UseSystemPasswordChar = true;
            }
            else
            {
                txtProductKey.UseSystemPasswordChar = false;
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtInputText.SelectionLength> 0)
                txtInputText.Copy();
            if(txtResult.SelectionLength>0)
                txtResult.Copy();
        }

    }
}
